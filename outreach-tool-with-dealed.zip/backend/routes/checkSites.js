const express = require("express");
const router = express.Router();
const Site = require("../models/Site");

function getRootDomain(fullUrl) {
  try {
    const { protocol, hostname } = new URL(fullUrl);
    return `${protocol}//${hostname}`;
  } catch {
    return null;
  }
}

router.post("/", async (req, res) => {
  const { links } = req.body;

  if (!Array.isArray(links)) return res.status(400).json({ error: "Invalid input" });

  const domains = [...new Set(links.map(getRootDomain).filter(Boolean))];
  const existing = await Site.find({ domain: { $in: domains } }).distinct("domain");
  const newSites = domains.filter(domain => !existing.includes(domain));

  await Site.insertMany(newSites.map(domain => ({ domain })), { ordered: false }).catch(() => {});

  res.json({ newSites });
});

module.exports = router;