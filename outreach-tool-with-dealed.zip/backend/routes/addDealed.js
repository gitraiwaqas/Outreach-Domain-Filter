const express = require("express");
const router = express.Router();
const Site = require("../models/Site");

router.post("/", async (req, res) => {
  const { domains } = req.body;

  if (!Array.isArray(domains)) return res.status(400).json({ error: "Invalid input" });

  const entries = domains.map(domain => ({
    domain,
    dealed: true,
    dealDate: new Date()
  }));

  await Site.insertMany(entries, { ordered: false }).catch(() => {});

  res.json({ message: "Dealed domains saved." });
});

module.exports = router;